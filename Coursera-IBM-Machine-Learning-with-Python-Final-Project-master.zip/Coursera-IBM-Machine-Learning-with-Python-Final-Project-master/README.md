# Coursera-IBM-Machine-Learning-with-Python-Final-Project
The following algorithms are used to build models for the different datasets: k-Nearest Neighbour, Decision Tree, Support Vector Machine, Logistic Regression.
The results is reported as the accuracy of each classifier, using the following metrics when these are applicable: Jaccard index, F1-score, Log Loss. 
